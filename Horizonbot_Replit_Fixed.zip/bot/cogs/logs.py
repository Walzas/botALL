from discord.ext import commands
import discord

class Logs(commands.Cog):
    def __init__(self, bot):
        self.bot = bot

    @commands.Cog.listener()
    async def on_message_delete(self, message):
        if message.author.bot:
            return
        log_channel = discord.utils.get(message.guild.text_channels, name="logs")
        if log_channel:
            await log_channel.send(f"🗑️ Message supprimé de {message.author}: {message.content}")

    @commands.Cog.listener()
    async def on_message_edit(self, before, after):
        if before.content == after.content:
            return
        log_channel = discord.utils.get(after.guild.text_channels, name="logs")
        if log_channel:
            await log_channel.send(f"✏️ Message édité par {before.author}:
Avant: {before.content}
Après: {after.content}")

    @commands.Cog.listener()
    async def on_member_update(self, before, after):
        log_channel = discord.utils.get(after.guild.text_channels, name="logs")
        if log_channel and before.roles != after.roles:
            added = [role for role in after.roles if role not in before.roles]
            removed = [role for role in before.roles if role not in after.roles]
            msg = f"👤 {before.name} a changé de rôle :"
            if added:
                msg += f"
➕ Ajouté : {', '.join([r.name for r in added])}"
            if removed:
                msg += f"
➖ Retiré : {', '.join([r.name for r in removed])}"
            await log_channel.send(msg)

def setup(bot):
    bot.add_cog(Logs(bot))
