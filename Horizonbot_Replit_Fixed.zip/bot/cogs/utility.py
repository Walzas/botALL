from discord.ext import commands

class Utility(commands.Cog):
    def __init__(self, bot):
        self.bot = bot

    @commands.command()
    async def serverinfo(self, ctx):
        guild = ctx.guild
        await ctx.send(f"Nom du serveur : {guild.name}\nMembres : {guild.member_count}")

def setup(bot):
    bot.add_cog(Utility(bot))
