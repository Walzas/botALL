import discord
from discord.ext import commands
import os
from dotenv import load_dotenv

load_dotenv()
intents = discord.Intents.all()
bot = commands.Bot(command_prefix='!', intents=intents)

@bot.event
async def on_ready():
    print(f'Logged in as {bot.user}!')

# Load cogs
for filename in os.listdir('./bot/cogs'):
    if filename.endswith('.py'):
        bot.load_extension(f'bot.cogs.{filename[:-3]}')

bot.run(os.getenv("TOKEN"))
